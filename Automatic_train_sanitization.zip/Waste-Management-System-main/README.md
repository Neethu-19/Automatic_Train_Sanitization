# Waste-Management-System
(Waste Wizard) The Waste Management System website. This GitHub repository hosts the source code for my waste management website, built with HTML, CSS, JS, and Bootstrap. Discover donation categories, arrange pickups, and explore our missions to make a meaningful impact on waste reduction. The website aims to revolutionize waste management system.
